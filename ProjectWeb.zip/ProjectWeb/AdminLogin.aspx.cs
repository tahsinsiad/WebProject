﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void AdminLoginButton_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        con.Open();
        SqlCommand select = new SqlCommand();
        select.Connection = con;

        select.CommandText = "select AdminUserName from adminpanel where AdminUserName='" + TextBoxAdminUser.Text.ToString() + "' and AdminPassword= '" + TextBoxPassword.Text.ToString() + "' ";
        SqlDataReader reader = select.ExecuteReader();
        if (reader.Read())
        {
            Session["Login"] = TextBoxAdminUser.Text.ToString();
            /*if (Login1.RememberMeSet == true)
            {
                HttpCookie usercookie;
                usercookie = Request.Cookies["Preferences"];
                if (usercookie == null)
                {
                    usercookie = new HttpCookie("Preferences");
                    usercookie.Expires = DateTime.Now.AddMonths(1);
                    Response.Cookies.Add(usercookie);
                }
            }*/
            Response.Redirect("AllFIRs.aspx");
        }
        reader.Close();
        con.Close();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
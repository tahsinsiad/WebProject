﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            
        } 
    }

    protected void Register_Click(object sender, EventArgs e)
    {
        /*string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        string insertSql = "INSERT INTO login1 (FirstName,LastName,username,password,Email,Gender,NID,Contact,Image) values(@FirstName,@LastName,@userName,@password,@Email,@Gender,@NID,@Contact,@Image)";
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = insertSql;

        SqlParameter firstName = new SqlParameter("@FirstName", SqlDbType.VarChar, 50);
        firstName.Value = txtFirstName.Text.ToString();
        cmd.Parameters.Add(firstName);

        SqlParameter lastName = new SqlParameter("@LastName", SqlDbType.VarChar, 50);
        lastName.Value = txtLastName.Text.ToString();
        cmd.Parameters.Add(lastName);

        SqlParameter userName = new SqlParameter("@userName", SqlDbType.VarChar, 50);
        userName.Value = txtUserName.Text.ToString();
        cmd.Parameters.Add(userName);

        SqlParameter password = new SqlParameter("@password", SqlDbType.VarChar, 50);
        password.Value = txtPwd.Text.ToString();
        cmd.Parameters.Add(password);

        SqlParameter Email = new SqlParameter("@Email", SqlDbType.VarChar, 50);
        Email.Value = txtEmailID.Text.ToString();
        cmd.Parameters.Add(Email);

        SqlParameter Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 50);
        Gender.Value = DropDownListGender.SelectedItem.ToString();
        cmd.Parameters.Add(Gender);

        SqlParameter NID = new SqlParameter("@NID", SqlDbType.VarChar, 50);
        NID.Value = txtNID.Text.ToString();
        cmd.Parameters.Add(NID);

        SqlParameter Contact = new SqlParameter("@Contact", SqlDbType.VarChar, 50);
        Contact.Value = txtContact.Text.ToString();
        cmd.Parameters.Add(Contact);

        if (fileuploadEmpImage.HasFile)
        {
            //getting length of uploaded file  
            int length = fileuploadEmpImage.PostedFile.ContentLength;
            //create a byte array to store the binary image data  
            byte[] imgbyte = new byte[length];
            //store the currently selected file in memeory  
            HttpPostedFile img = fileuploadEmpImage.PostedFile;
            //set the binary data  
            img.InputStream.Read(imgbyte, 0, length);
            cmd.Parameters.Add("@Image", SqlDbType.Image).Value = imgbyte;
        }


        


       

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            //lblMsg.Text = "User Registration Successful!!!";
            Response.Write("Registration Successful!!!");
            ClearControls(Page);
        }
        catch (SqlException ex)
        {
            string errorMessage = "Error in registering user!";
            errorMessage += ex.Message;
            throw new Exception(errorMessage);
        }
        finally
        {
            con.Close();

        }*/

        try
        {
            //Response.Write("Hello");
            //Condition to check if the file uploaded or not   
            if (fileuploadEmpImage.HasFile)
            {
                //Response.Write("Hello");
                //getting length of uploaded file  
                int length = fileuploadEmpImage.PostedFile.ContentLength;
                //create a byte array to store the binary image data  
                byte[] imgbyte = new byte[length];
                //store the currently selected file in memeory  
                HttpPostedFile img = fileuploadEmpImage.PostedFile;
                //set the binary data  
                img.InputStream.Read(imgbyte, 0, length);
                //int id = Convert.ToInt32(txtID.Text);
                string Fname = txtFirstName.Text;
                string Lname = txtLastName.Text;
                string Uname = txtUserName.Text;
                string Pass = txtPwd.Text;
                string Email = txtEmailID.Text;
                
                string NID = txtNID.Text;
                string CN = txtContact.Text;

                

                //Connection String  
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-36G8I2L\SQLEXPRESS;Initial Catalog=FIR;User ID=siad27;Password=periodictable114");
                //Open The Connection  
                connection.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO login1 (FirstName,LastName,username,password,Email,Gender,NID,Contact,Image) values(@FirstName,@LastName,@userName,@password,@Email,@Gender,@NID,@Contact,@Image)", connection);
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar,50).Value = Fname;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar, 50).Value = Lname;
                cmd.Parameters.Add("@username", SqlDbType.VarChar, 50).Value = Uname;
                cmd.Parameters.Add("@password", SqlDbType.VarChar, 50).Value = Pass;
                cmd.Parameters.Add("@Email", SqlDbType.VarChar, 50).Value = Email;
                SqlParameter Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 50);
                Gender.Value = DropDownListGender.SelectedItem.ToString();
                cmd.Parameters.Add(Gender);
                cmd.Parameters.Add("@NID", SqlDbType.VarChar, 50).Value = NID;
                cmd.Parameters.Add("@Contact", SqlDbType.VarChar, 50).Value = CN;
                
                cmd.Parameters.Add("@Image", SqlDbType.Image).Value = imgbyte;
                cmd.ExecuteNonQuery();
                //int count = cmd.ExecuteNonQuery();
                //Close The Connection  





                //call the method to bind the grid  
                
                connection.Close();
                
            }
        }
        catch (Exception)
        {     //error     }
        }


    }
    /*public static void ClearControls(Control Parent)
    {
        foreach (Control c in Parent.Controls)
            ClearControls(c);
    }*/
}
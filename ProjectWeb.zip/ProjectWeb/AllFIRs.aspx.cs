﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class AllFIRs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       /* if (!IsPostBack)
        {
            if (Session["Login"] == null)
            {
                Response.Redirect("AdminLogin.aspx");
            }
            else
            {

                //this.Profile1.Text = Session["Login"].ToString();

                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache,no-store,max-age=0,must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
                fillDataGrid();
            }
        }*/

        
    }

    public void fillDataGrid()
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        
        SqlCommand cmd = new SqlCommand("select * from Fir", con);
        con.Open();
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        adapter.Fill(ds, "Fir");
        datagridview.DataSource = ds.Tables[0];
        datagridview.DataBind();
        con.Close();
    }
    protected void datagridview_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        datagridview.PageIndex = e.NewPageIndex;
        fillDataGrid();
    }
    protected void datagridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        //Here we will be passing the command name which we assigned to the button
        if (e.CommandName == "ViewDetails")
        {
            int rowno = Int32.Parse(e.CommandArgument.ToString());  // It is the rowno of which the user as clicked

            string Name = datagridview.Rows[rowno].Cells[1].Text.ToString();  // logical 0,1,2,3,4,5
            lbl1.Text = "Victim's Name       : " + Name;

            string NID = datagridview.Rows[rowno].Cells[4].Text.ToString();
            lbl2.Text = "Victim's NID        : " + NID;

            string PresentAddress = datagridview.Rows[rowno].Cells[5].Text.ToString();
            lbl3.Text = "Present Address     : " + PresentAddress;

            string HomeDistrict = datagridview.Rows[rowno].Cells[6].Text.ToString();
            lbl4.Text = "Home District       : " + HomeDistrict;

            string HomePolice = datagridview.Rows[rowno].Cells[7].Text.ToString();
            lbl5.Text = "Home Police Station : " + HomePolice;



            string Gender = datagridview.Rows[rowno].Cells[8].Text.ToString();  // logical 0,1,2,3,4,5
            lbl6.Text = "Gender              : " + Gender;

            string Birth = datagridview.Rows[rowno].Cells[9].Text.ToString();
            lbl7.Text = "Date Of Birth       : " + Birth;

            string Nationality = datagridview.Rows[rowno].Cells[10].Text.ToString();
            lbl8.Text = "Nationality         : " + Nationality;

            string MarritalStatus = datagridview.Rows[rowno].Cells[11].Text.ToString();
            lbl9.Text = "Marrital Status     : " + MarritalStatus;

            string DateOfIncident = datagridview.Rows[rowno].Cells[12].Text.ToString();  // logical 0,1,2,3,4,5
            lbl10.Text = "Date Of Incident   : " + DateOfIncident;

            string TimeOfIncident = datagridview.Rows[rowno].Cells[13].Text.ToString();
            lbl11.Text = "Time Of Incident   : " + TimeOfIncident;

            string PlaceOfIncident = datagridview.Rows[rowno].Cells[14].Text.ToString();
            lbl12.Text = "Place Of Incident  : " + PlaceOfIncident;

            string Details = datagridview.Rows[rowno].Cells[17].Text.ToString();
            lbl13.Text = "Details Of Incident : " + Details;
            
        }
    }

    protected void LogOutButton_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("AdminLogin.aspx");
    }
}
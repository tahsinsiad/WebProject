﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Data;
public partial class UploadPhoto : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            
        }    
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //Condition to check if the file uploaded or not   
            if (fileuploadEmpImage.HasFile)
            {
                //getting length of uploaded file  
                int length = fileuploadEmpImage.PostedFile.ContentLength;
                //create a byte array to store the binary image data  
                byte[] imgbyte = new byte[length];
                //store the currently selected file in memeory  
                HttpPostedFile img = fileuploadEmpImage.PostedFile;
                //set the binary data  
                img.InputStream.Read(imgbyte, 0, length);
                int id = Convert.ToInt32(txtID.Text);
                string name = txtName.Text;
                string bloodGroup = txtBloodGroup.Text;
                string phoneNo = txtContactNo.Text;

                //Connection String  
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-36G8I2L\SQLEXPRESS;Initial Catalog=FIR;User ID=siad27;Password=periodictable114");
                //Open The Connection  
                connection.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Employee (Id,Name,BloodGroup,ContactNo,Image) VALUES (@Id,@Name,@BloodGroup,@ContactNo,@Image)", connection);
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 150).Value = name;
                cmd.Parameters.Add("@BloodGroup", SqlDbType.NVarChar, 250).Value = bloodGroup;
                cmd.Parameters.Add("@ContactNo", SqlDbType.VarChar, 50).Value = phoneNo;
                cmd.Parameters.Add("@Image", SqlDbType.Image).Value = imgbyte;
                cmd.ExecuteNonQuery();
                //int count = cmd.ExecuteNonQuery();
                //Close The Connection  




                //call the method to bind the grid  
                //BindGridData();
                connection.Close();

            }
        }
        catch (Exception)
        {     //error     }
        }
    }

    
}
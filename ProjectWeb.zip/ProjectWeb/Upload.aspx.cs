﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
public partial class Upload : System.Web.UI.Page
{
    string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
         
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            Byte[] bytes = null;
            if (FileUpload1.HasFile)
            {
                string filename = FileUpload1.PostedFile.FileName;
                string filePath = Path.GetFileName(filename);
 
                Stream fs = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                bytes = br.ReadBytes((Int32)fs.Length);
            }
             
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(
                 "INSERT INTO tblImage (ImageName, Image) " +
                 "Values(@ImageName, @Image)", connection); 
                command.Parameters.Add("@ImageName",
                SqlDbType.NVarChar, 20).Value = txtImageName.Text;
                command.Parameters.Add("@Image",
                SqlDbType.Binary).Value = bytes; 
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        catch (Exception)
        {     //error     }

    }
    }



    protected void bindGrid()
    {
         DataSet ds = new DataSet();
         
         using (SqlConnection connection = new SqlConnection(connectionString))
         {
             connection.Open();
             string cmdstr = "Select ImageID, ImageName from tblImage";
             SqlCommand cmd = new SqlCommand(cmdstr, connection);
             SqlDataAdapter adp = new SqlDataAdapter(cmd);
             adp.Fill(ds);
             gvDetails.DataSource = ds;
             gvDetails.DataBind();
         } 


    }




}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

using System.Web.Services;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class LocalPoliceTeam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        string com = "Select * from LocalPoliceTeams";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);*/
       
        
        
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("select * from LocalPoliceTeams where PoliceStation = '" + DropDownDMP.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView2.DataSource = dt;
        GridView2.DataBind();
        
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("select * from LocalPoliceTeams where PoliceStation = '" + DropDownCMP.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView3.DataSource = dt;
        GridView3.DataBind();
    }

   
    protected void Button3_Click1(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("select * from LocalPoliceTeams where PoliceStation = '" + DropDownKMP.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView4.DataSource = dt;
        GridView4.DataBind();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("select * from LocalPoliceTeams where PoliceStation = '" + DropDownRMP.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView5.DataSource = dt;
        GridView5.DataBind();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("select * from LocalPoliceTeams where PoliceStation = '" + DropDownBMP.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView6.DataSource = dt;
        GridView6.DataBind();
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("select * from LocalPoliceTeams where PoliceStation = '" + DropDownSMP.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView7.DataSource = dt;
        GridView7.DataBind();
    }


    [WebMethod]
    public static string[] GetCustomers(string prefix)
    {
        List<string> customers = new List<string>();
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select PoliceStation, Telephone from LocalPoliceTeams where PoliceStation like @SearchText + '%'";
                cmd.Parameters.AddWithValue("@SearchText", prefix);
                cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        customers.Add(string.Format("{0}-{1}", sdr["PoliceStation"], sdr["Telephone"]));
                    }
                }
                conn.Close();
            }
        }
        return customers.ToArray();
    }


    protected void Searchbtn_Click(object sender, EventArgs e)
    {
        string policestation = Request.Form[TextBoxSearch.UniqueID];
        string mobileno = Request.Form[hPolicestation.UniqueID];
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('PoliceStation: " + policestation + "\\nMobileNo: " + mobileno + "');", true);
    }
}